const cloudinary = require("cloudinary").v2;

cloudinary.config({
  cloud_name: "dzmexswgf",
  api_key: "363452167794787",
  api_secret: "wg4Z9YNLwW8TY6d7JP9Etnx-gNs",

  });


  module.exports = cloudinary;