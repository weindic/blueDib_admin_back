
// const User = require("../Model/users.model");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");
const mongoose = require('mongoose')
const ObjectId = mongoose.Types.ObjectId;




exports.getAllUsers = async () => {
    try {
        // Access the 'users' collection using Mongoose's existing connection
        const usersCollection = mongoose.connection.collection('User');

        // Find all users in the 'users' collection and convert the cursor to an array
        const users = await usersCollection.find().toArray();

        console.log('users', users)

        return {
            data: users,
            status: true,
            message: 'Users retrieved successfully',
        };
    } catch (error) {
        console.error('Error occurred while retrieving users:', error);
        return {
            data: null,
            status: false,
            message: 'An error occurred while retrieving users',
        };
    }
};



exports.getTransactions = async () => {
    try {
        // Access the 'Transaction' collection using Mongoose's existing connection
        const transactionCollection = mongoose.connection.collection('Transaction');

        // Perform the lookup between Transaction and User collections
        const transactions = await transactionCollection.aggregate([
            {
                $lookup: {
                    from: 'User', // Name of the 'User' collection
                    localField: 'buyer_id', // Field in 'Transaction' collection
                    foreignField: '_id', // Field in 'User' collection
                    as: 'buyerData' // Output array field name for buyer data
                }
            },
            {
                $lookup: {
                    from: 'User', // Name of the 'User' collection
                    localField: 'seller_id', // Field in 'Transaction' collection
                    foreignField: '_id', // Field in 'User' collection
                    as: 'sellerData' // Output array field name for seller data
                }
            },
            {
                $unwind: {
                    path: '$buyerData',
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $unwind: {
                    path: '$sellerData',
                    preserveNullAndEmptyArrays: true
                }
            }
        ]).toArray();


        console.log(transactions)

        return {
            data: transactions,
            status: true,
            message: 'Transactions retrieved successfully',
        };
    } catch (error) {
        console.error('Error occurred while retrieving Transactions:', error);
        return {
            data: null,
            status: false,
            message: 'An error occurred while retrieving Transactions',
        };
    }
};


exports.getWithdrawData = async () => {
    try {
        // Access the 'WithDrawalRequest' collection using Mongoose's existing connection
        const withDrawalRequestCollection = mongoose.connection.collection('WithDrawalRequest');

        // Perform the lookup between WithDrawalRequest and User collections
        const requests = await withDrawalRequestCollection.aggregate([
            {
                $lookup: {
                    from: 'User', // Name of the 'User' collection
                    localField: 'userId', // Field in 'WithDrawalRequest' collection
                    foreignField: '_id', // Field in 'User' collection
                    as: 'userData' // Output array field name for user data
                }
            },
            {
                $unwind: {
                    path: '$userData',
                    preserveNullAndEmptyArrays: true
                }
            }
        ]).toArray();

        console.log(requests);

        return {
            data: requests,
            status: true,
            message: 'Withdrawal requests retrieved successfully',
        };
    } catch (error) {
        console.error('Error occurred while retrieving Withdrawal requests:', error);
        return {
            data: null,
            status: false,
            message: 'An error occurred while retrieving Withdrawal requests',
        };
    }
};



exports.getPaymentRequest = async () => {
    try {
        // Access the 'AddFundRequest' collection using Mongoose's existing connection
        const addFundRequestCollection = mongoose.connection.collection('AddFundRequest');

        // Perform the lookup between AddFundRequest and User collections
        const requests = await addFundRequestCollection.aggregate([
            {
                $lookup: {
                    from: 'User', // Name of the 'User' collection
                    localField: 'userId', // Field in 'AddFundRequest' collection
                    foreignField: '_id', // Field in 'User' collection
                    as: 'userData' // Output array field name for user data
                }
            },
            {
                $unwind: {
                    path: '$userData',
                    preserveNullAndEmptyArrays: true
                }
            },
            {
                $lookup: {
                    from: 'PaymentMethod', // Name of the 'PaymentMethod' collection
                    localField: 'userData._id', // Field in 'AddFundRequest' collection (through user data)
                    foreignField: 'userId', // Field in 'PaymentMethod' collection
                    as: 'paymentMethodData' // Output array field name for payment method data
                }
            },
            {
                $unwind: {
                    path: '$paymentMethodData',
                    preserveNullAndEmptyArrays: true
                }
            }
        ]).toArray();

        console.log(requests);

        return {
            data: requests,
            status: true,
            message: 'Payment requests retrieved successfully',
        };
    } catch (error) {
        console.error('Error occurred while retrieving Payment requests:', error);
        return {
            data: null,
            status: false,
            message: 'An error occurred while retrieving Payment requests',
        };
    }
};
