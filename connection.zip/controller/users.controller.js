const Service = require("../Service/users.service");


// users controller=======================//

// getAll admins
exports.getAllUsers = async (req, res) => {
    try {
      const data = await Service.getAllUsers();
      return res.status(200).json(data);
    } catch (error) {
      console.error("An error occurred in getAllAdmins controller:", error);
      return res.status(500).json({
        data: null,
        status: false,
        message: "Internal server error",
      });
    }
  };


  exports.getTransactions = async (req, res) => {
    try {
      const data = await Service.getTransactions();
      return res.status(200).json(data);
    } catch (error) {
      console.error("An error occurred in getAllAdmins controller:", error);
      return res.status(500).json({
        data: null,
        status: false,
        message: "Internal server error",
      });
    }
  };


  exports.getWithdrawData = async (req, res) => {
    try {
      const data = await Service.getWithdrawData();
      return res.status(200).json(data);
    } catch (error) {
      console.error("An error occurred in getAllAdmins controller:", error);
      return res.status(500).json({
        data: null,
        status: false,
        message: "Internal server error",
      });
    }
  };


  exports.getPaymentRequest = async (req, res) => {
    try {
      const data = await Service.getPaymentRequest();
      return res.status(200).json(data);
    } catch (error) {
      console.error("An error occurred in getAllAdmins controller:", error);
      return res.status(500).json({
        data: null,
        status: false,
        message: "Internal server error",
      });
    }
  };


