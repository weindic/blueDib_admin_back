const mongoose = require("mongoose");
const UserSchema = new mongoose.Schema({
    firebaseId: {
        type: String,
        required: true,
        unique: true
    },
    avatarPath: {
        type: String
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    username: {
        type: String,
        required: true,
        unique: true
    },
    bio: {
        type: String
    },
    followers: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    followersIDs: [{
        type: mongoose.Schema.Types.ObjectId
    }],
    following: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    followingIDs: [{
        type: mongoose.Schema.Types.ObjectId
    }],
    posts: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Post'
    }],
    postLikedIDs: [{
        type: mongoose.Schema.Types.ObjectId
    }],
    postsLiked: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Post'
    }],
    comments: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Comment'
    }],
    pan: {
        type: String
    },
    shares: {
        type: Number,
        default: 10000000
    },
    balance: {
        type: Number,
        default: 0
    },
    price: {
        type: Number,
        default: 1
    },
    userEquity: {
        type: Number,
        default: 10
    },
    platformEquity: {
        type: Number,
        default: 2.5
    },
    holdings: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Holding'
    }],
    sold: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Holding'
    }],
    sellTransactions: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Transaction'
    }],
    buyTransactions: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Transaction'
    }],
    addFundRequests: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'AddFundRequest'
    }],
    mobile: {
        type: String
    },
    gender: {
        type: String,
        enum: ['Male', 'Female', 'Other']
    },
    dob: {
        type: Date
    },
    lastSell: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'LastSell'
    },
    withdrawalRequests: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'WithDrawalRequest'
    }],
    paymentMethods: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'PaymentMethod'
    }],
    platformSellRequests: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'PlatformSellRequest'
    }],
    verified: {
        type: Boolean,
        default: false
    },
    otpSentTime: {
        type: Date
    },
    otp: {
        type: Number
    },
    activated: {
        type: Boolean,
        default: false
    }
}, {
    timestamps: true // Automatically adds createdAt and updatedAt fields
});

// Add unique compound index
// UserSchema.index({ email: 1, username: 1 }, { unique: true });

// Add model ID to schema
// UserSchema.index({ _id: 1 }, { unique: true });


const User = mongoose.model('User', UserSchema);

module.exports = User;
